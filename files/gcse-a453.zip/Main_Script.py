#---------------------------------------------------------------------------------------------------------------#
#                                                                                                               #
#                                               MATHS QUIZ                                                      #
#                                               v0.5 - Exam                                                     #
#                                                                                                               #
#                                               Python 3.3                                                      #
#                                       SOLE PROPERTY OF W.MULROONEY                                            #
#                                                                                                               #
#---------------------------------------------------------------------------------------------------------------#

#---------------------------------------------------------------------------------------------------------------#
#                                                  IMPORTS                                                      #
#                These imports load key functions that are needed to run certain bits of code.                  #
#---------------------------------------------------------------------------------------------------------------#

import os                       # Imports functions from 'os'
import os.path                  # Imports functions from 'path' in 'os'
import sqlite3 as sql           # Imports functions from 'sqlite3' under the name 'sql'
import time                     # Imports functions from 'time'
import math                     # Imports functions from 'math'
import random                   # Imports functions from 'random'
import subprocess               # Imports functions from 'subprocess'
import sys                      # Imports functions from 'sys'

#---------------------------------------------------------------------------------------------------------------#
#                                                INITIAL FLOATS                                                 #
#              These integers set the initial value of 0 questions correct and 0 questions incorrect.           #
#---------------------------------------------------------------------------------------------------------------#

anscorrect = int(0)
answrong = int(0)

#---------------------------------------------------------------------------------------------------------------#
#                                                 EXECUTION                                                     #
#  This is the start of the introductory section of the code. We collect the user's name and class if they're a #
#  student and redirect staff to the staff module.                                                              #
#---------------------------------------------------------------------------------------------------------------#

# Below is the code to print the title block that shows that it is the maths quiz and that it is made by
# W.Mulrooney
print("#----------------------------------------------------------#")
print("#                                                          #")
print("#                      Maths Quiz                          #")
print("#                 Made by: W.Mulrooney                     #")
print("#                                                          #")
print("#----------------------------------------------------------#")

# Below, the user is prompted for their name, it is then saved under the variable "inpuser".
print("#                                                          #")
print("#    Please enter your name.                               #")
inpuser = input("#     >")

# If the inputted name is "Staff" then the staff member is welcomed and then "Staff_Module.py" starts, which
# handles data being pulled from databases. The program then stops and the staff member is left with the staff module.
if inpuser == "Staff" or inpuser == "staff":
    print("#                                                          #")
    print("#    Welcome back valued staff member!                     #")
    print("#                                                          #")
    os.startfile("Staff_Module.py")
    sys.exit()

# If the inputted name isn't "Staff" then the progam proceedes to ask what class the student is in. This will later
# be used to determine which database the data will be inputted into.
else:
    print("#                                                          #")
    print("#    Please enter your class from the list below!          #")
    print("#                                                          #")
    print("#    05A                                                   #")
    print("#    05B                                                   #")
    print("#    05C                                                   #")
    print("#                                                          #")
    inpclass = input("#     >")

    # If the class inputted is on the list displayed, then continue.
    if inpclass == "05A" or inpclass == "05B" or inpclass == "05C":
        print("#                                                          #")

    # If the class inputted is not on the list then state there is an error then exit the program.
    else:
        print("#                                                          #")
        print("#    ERROR: Class not found!                               #")
        print("#                                                          #")
        print("#    Please restart the program!                           #")
        print("#                                                          #")
        print("#----------------------------------------------------------#")
        time.sleep(5)
        sys.exit()

# Some information about the quiz is displayed for six seconds before the program starts.
print("#                                                          #")
print("#    Welcome to the maths quiz student! You will be        #")
print("#    asked 10 questions and you results will be shown      #")
print("#    and sent to your teacher!                             #")
print("#                                                          #")
print("#----------------------------------------------------------#")
time.sleep(6)

#---------------------------------------------------------------------------------------------------------------#
#                                                 QUESTIONS                                                     #
#---------------------------------------------------------------------------------------------------------------#

# Two random numbers between 1 and 10 are generated and assigned to two variables.
num_1 = random.randrange(1,10)
num_2 = random.randrange(1,10)

# The program prints the question, by factoring in the two random values.
print("#                                                          #")
print("#    What is %s + %s ?                                       #" % (num_1, num_2))
print("#                                                          #")

# The program then works out the answer to the question and then prompts the input. The input is then converted
# into an integer value.
act_answer = (num_1) + (num_2)
inp_answer = input("#     >")
inp_answer = int(inp_answer)

# The progam then checks to see whether the inputted answer is exactly the same as the answer that was calculated
# before the prompting.
#
# If the input was correct, then it display that it was correct. After that, it increases the correct answers value.
if inp_answer == (act_answer):
    print("#                                                          #")
    print("#    Well done, that was correct!                          #")
    print("#                                                          #")
    anscorrect += 1

# If the input was anything else, then the progam displays that it is incorrect and increases the answers wrong value.
else:
    print("#                                                          #")
    print("#    Sorry, that was incorrect!                            #")
    print("#                                                          #")
    answrong += 1

#-----------------#

# Here we loop three lots of the questions above three times. This means that the following order of operators is uses:
# ++-*+-*+-*
# 10 questions with addition, subtraction and multiplication.
for x in range(0,3):
    num_1 = random.randrange(1,10)
    num_2 = random.randrange(1,10)
    print("#                                                          #")
    print("#    What is %s + %s ?                                       #" % (num_1, num_2))
    print("#                                                          #")
    act_answer = (num_1) + (num_2)
    inp_answer = input("#     >")
    inp_answer = int(inp_answer)

    if inp_answer == (act_answer):
        print("#                                                          #")
        print("#    Well done, that was correct!                          #")
        print("#                                                          #")
        anscorrect += 1

    else:
        print("#                                                          #")
        print("#    Sorry, that was incorrect!                            #")
        print("#                                                          #")
        answrong += 1

    #-----------------#

    num_1 = random.randrange(1,10)
    num_2 = random.randrange(1,10)
    print("#                                                          #")
    print("#    What is %s - %s ?                                       #" % (num_1, num_2))
    print("#                                                          #")
    act_answer = (num_1) - (num_2)
    inp_answer = input("#     >")
    inp_answer = int(inp_answer)

    if inp_answer == (act_answer):
        print("#                                                          #")
        print("#    Well done, that was correct!                          #")
        print("#                                                          #")
        anscorrect += 1

    else:
        print("#                                                          #")
        print("#    Sorry, that was incorrect!                            #")
        print("#                                                          #")
        answrong += 1

    #-----------------#

    num_1 = random.randrange(1,10)
    num_2 = random.randrange(1,10)
    print("#                                                          #")
    print("#    What is %s x %s ?                                       #" % (num_1, num_2))
    print("#                                                          #")
    act_answer = (num_1) * (num_2)
    inp_answer = input("#     >")
    inp_answer = int(inp_answer)

    if inp_answer == (act_answer):
        print("#                                                          #")
        print("#    Well done, that was correct!                          #")
        print("#                                                          #")
        anscorrect += 1

    else:
        print("#                                                          #")
        print("#    Sorry, that was incorrect!                            #")
        print("#                                                          #")
        answrong += 1

    #-----------------#



#---------------------------------------------------------------------------------------------------------------#
#                                                  END MSG                                                      #
#---------------------------------------------------------------------------------------------------------------#

# Upon completion of the quiz the following message is displayed. It shows how many answers were correct and how
# many were incorrect. It also then reprints the correct answers in a ten-out-of-ten format. Each variable is
# formatted to the appropriate format (string in this case).
print("#----------------------------------------------------------#")
print("#                                                          #")
print("#    Congratulations, you have finished the test!          #")
print("#                                                          #")
print("#    Here are your scores...                               #")
print("#      Correct: {}".format(anscorrect))
print("#      Incorrect: {}".format(answrong))
print("#                                                          #")
print("#       {}/10                                               #".format(anscorrect))
print("#                                                          #")
print("#----------------------------------------------------------#")
time.sleep(10)

#---------------------------------------------------------------------------------------------------------------#
#                                             SQL DATA RECORDING                                                #
#---------------------------------------------------------------------------------------------------------------#


# 05A Database Entry #
# If the inputted class was "05A" then a connection will be established to the 05A database under the variable "con". Then a cursor
# is created for this connection under the variable "c".
if inpclass == "05A":
    
    con = sql.connect('\\\\tssd003\\Students\\002690\\KS4\\Computing Science\\A453\\# MATHS QUIZ\\0.6 - Later Exam\\Python 3\\Databases\\A_Data.db')
    c = con.cursor()

    # The variables that track the scores are formatted into integers, just to make sure there will be no issues.
    anscorrect = int(anscorrect)
    answrong = int(answrong)

    # The cursor executes the command of inserting the results into the table called, "Results". The inputted
    # user, the correct answer value and the wrong answer values are factored into the data insert.
    c.execute("INSERT INTO Results VALUES (?, ?, ?)", (inpuser, anscorrect, answrong))

    # The database is saved and the connection closed
    con.commit()
    con.close()


# 05B Database Entry #
# If the inputted class was "05B" then a connection will be established to the 05B database under the variable "con". Then a cursor
# is created for this connection under the variable "c".
elif inpclass == "05B":
    
    con = sql.connect('\\\\tssd003\\Students\\002690\\KS4\\Computing Science\\A453\\# MATHS QUIZ\\0.6 - Later Exam\\Python 3\\Databases\\B_Data.db')
    c = con.cursor()

    # The variables that track the scores are formatted into integers, just to make sure there will be no issues.
    anscorrect = int(anscorrect)
    answrong = int(answrong)

    # The cursor executes the command of inserting the results into the table called, "Results". The inputted
    # user, the correct answer value and the wrong answer values are factored into the data insert.
    c.execute("INSERT INTO Results VALUES (?, ?, ?)", (inpuser, anscorrect, answrong))

    # The database is saved and the connection closed
    con.commit()
    con.close()


# 05C Database Entry #
# If the inputted class was "05C" then a connection will be established to the 05C database under the variable "con". Then a cursor
# is created for this connection under the variable "c".
if inpclass == "05C":
    
    con = sql.connect('\\\\tssd003\\Students\\002690\\KS4\\Computing Science\\A453\\# MATHS QUIZ\\0.6 - Later Exam\\Python 3\\Databases\\C_Data.db')
    c = con.cursor()

    # The variables that track the scores are formatted into integers, just to make sure there will be no issues.
    anscorrect = int(anscorrect)
    answrong = int(answrong)

    # The cursor executes the command of inserting the results into the table called, "Results". The inputted
    # user, the correct answer value and the wrong answer values are factored into the data insert.
    c.execute("INSERT INTO Results VALUES (?, ?, ?)", (inpuser, anscorrect, answrong))

    # The database is saved and the connection closed
    con.commit()
    con.close()


# A goodbye message is displayed and the program comes to a close.
print("#                                                          #")
print("#       Thank you for taking the maths quiz, goodbye.      #")
print("#                                                          #")
print("#----------------------------------------------------------#")
print("#----------------------END OF QUIZ-------------------------#")
print("#----------------------------------------------------------#")
time.sleep(3)
sys.exit()

