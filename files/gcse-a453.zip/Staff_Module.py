#---------------------------------------------------------------------------------------------------------------#
#                                                                                                               #
#                                               STAFF MODULE                                                    #
#                                               v0.5 - Exam                                                     #
#                                                                                                               #
#                                               Python 3.3                                                      #
#                                       SOLE PROPERTY OF W.MULROONEY                                            #
#                                                                                                               #
#---------------------------------------------------------------------------------------------------------------#

# NEEDS ANNOTATING FURTHER

#---------------------------------------------------------------------------------------------------------------#
#                                                  IMPORTS                                                      #
#---------------------------------------------------------------------------------------------------------------#

import os                   # Imports functions from 'os'.
import os.path              # Imports functions from 'path' in 'os'.
import time                 # Imports functions from 'time'.
import math                 # Imports functions from 'math'.
import random               # Imports functions from 'random'.
import subprocess           # Imports functions from 'subprocess'.
import sqlite3 as sql       # Imports functions from 'sqlite3' under the name 'sql'.

#---------------------------------------------------------------------------------------------------------------#
#                                                START MSG                                                      #
#---------------------------------------------------------------------------------------------------------------#

# A welcome message is displayed.
print("#----------------------------------------------------------#")
print("#                                                          #")
print("#    Welcome to the staff module for the maths quiz.       #")
print("#                                                          #")
print("#----------------------------------------------------------#")
print("#                                                          #")

# The user is asked which class they would like to work with, their input is saved under the variable
# "selected_class".
print("#     Which class do you wish to view?                     #")
print("#                                                          #")
selected_class = input("#    >")
print("#                                                          #")
print("#----------------------------------------------------------#")

# The user is prompted to enter their desired actions. It is said specifically that they are to enter the number.
# Their input is saved under the variable "action_a".
print("#                                                          #")
print("#     What would you like to do? (Enter the number)        #")
print("#                                                          #")
print("#     \'1\' - Show all scores of a class.                    #")
print("#     \'2\' - Search the class.                              #")
print("#                                                          #")
action_a = input("#    >")
print("#                                                          #")
print("#----------------------------------------------------------#")


#---------------------------------------------------------------------------------------------------------------#
#                                                 VIEW ALL                                                      #
#---------------------------------------------------------------------------------------------------------------#

# If the inputted action was to show all the scores of the class then it will ask the user how they want it to be
# displayed. Their input is recorded under the variable "action_b".
if action_a == "1":

    print("#                                                          #")
    print("#     How would you like to view the data?                 #")
    print("#                                                          #")
    print("#     \'1\' - In alphabetical order                          #")
    print("#     \'2\' - Show all scores in highest to lowest order.    #")
    print("#     \'3\' - View the average score for the class.          #")
    print("#                                                          #")
    action_b = input("#    >")
    print("#                                                          #")
    print("#----------------------------------------------------------#")

    # If their action was to show it in alphabetical order, then a connection is established to the appropriate
    # database, based on their selected class, which is operated with embeded if statements. A cursor is created
    # under the variable "c".
    if action_b == "1":
        if selected_class == "05A":
            con = sql.connect('\\\\tssd003\\Students\\002690\\KS4\\Computing Science\\A453\\# MATHS QUIZ\\0.6 - Later Exam\\Python 3\\Databases\\BA_Data.db')
            c = con.cursor()

            # The cursor executes a select query and selects everything from the table and saves it under the
            # variable "r".
            c.execute('''SELECT * FROM Results''')
            r = c.fetchall()

            # "r" is printed, along with some explaination.
            print("#----------------------------------------------------------#")
            print("#                     // Layout //                         #")
            print("# |('Name', 'First Score', 'Second Score', 'Third Score')| #")
            print("#                                                          #")
            print(sorted(r))    # "r" was sorted during the printing process.

            # The connection is closed, there is no need to save.
            con.close()

        # The same process as above is repeated, but with certain figures changed to fit the class of 05B.
        elif selected_class == "05B":
            con = sql.connect('\\\\tssd003\\Students\\002690\\KS4\\Computing Science\\A453\\# MATHS QUIZ\\0.6 - Later Exam\\Python 3\\Databases\\BB_Data.db')
            c = con.cursor()
        
            c.execute('''SELECT * FROM Results''')
            r = c.fetchall()

            print("#----------------------------------------------------------#")
            print("#                     // Layout //                         #")
            print("# |('Name', 'First Score', 'Second Score', 'Third Score')| #")
            print("#                                                          #")

            print(sorted(r))

            con.close()

        # The same process as above is repeated, but with certain figures changed to fit the class of 05C.
        elif selected_class == "05C":
            con = sql.connect('\\\\tssd003\\Students\\002690\\KS4\\Computing Science\\A453\\# MATHS QUIZ\\0.6 - Later Exam\\Python 3\\Databases\\BC_Data.db')
            c = con.cursor()
        
            c.execute('''SELECT * FROM Results''')
            r = c.fetchall()

            print("#----------------------------------------------------------#")
            print("#                     // Layout //                         #")
            print("# |('Name', 'First Score', 'Second Score', 'Third Score')| #")
            print("#                                                          #")

            print(sorted(r))

            con.close()

    #-----------------------#

    elif action_b == "2":

        con = sql.connect('\\\\tssd003\\Students\\002690\\KS4\\Computing Science\\A453\\# MATHS QUIZ\\0.6 - Later Exam\\Python 3\\Databases\\BA_Data.db')
        c = con.cursor()
        
        c.execute('''SELECT * FROM Results''')
        r = c.fetchall()

    #-----------------------#

    elif action_b == "3":

        con = sql.connect('\\\\tssd003\\Students\\002690\\KS4\\Computing Science\\A453\\# MATHS QUIZ\\0.6 - Later Exam\\Python 3\\Databases\\BA_Data.db')
        c = con.cursor()
        
        c.execute('''SELECT * FROM Results''')
        r = c.fetchall()



#---------------------------------------------------------------------------------------------------------------#
#                                             SEARCHING CLASS                                                   #
#---------------------------------------------------------------------------------------------------------------#


elif action_a == "2":
    print("#                                                          #")
    print("#                CLASS SEARCH BY NAME                      #")
    print("#                                                          #")
    print("#                     // Layout //                         #")
    print("# |('Name', 'First Score', 'Second Score', 'Third Score')| #")
    print("#                                                          #")

    searchedname = input("#    >")



    #----------------# 05A PROCEDURE #----------------#

    if selected_class == "05A":
    
        con = sql.connect('\\\\tssd003\\Students\\002690\\KS4\\Computing Science\\A453\\# MATHS QUIZ\\0.6 - Later Exam\\Python 3\\Databases\\BA_Data.db')
        c = con.cursor()

        c.execute("SELECT * FROM Results WHERE Name=?", (searchedname,))
        r = c.fetchall()

        print(sorted(r))

        con.close()



    #----------------# 05B PROCEDURE #----------------#

    elif selected_class == "05B":

        con = sql.connect('\\\\tssd003\\Students\\002690\\KS4\\Computing Science\\A453\\# MATHS QUIZ\\0.6 - Later Exam\\Python 3\\Databases\\BB_Data.db')
        c = con.cursor()

        c.execute("SELECT * FROM Results WHERE Name=?", (searchedname,))
        r = c.fetchall()

        print(sorted(r))

        con.close()


    #----------------# 05C PROCEDURE #----------------#
        
    elif selected_class == "05C":

        con = sql.connect('\\\\tssd003\\Students\\002690\\KS4\\Computing Science\\A453\\# MATHS QUIZ\\0.6 - Later Exam\\Python 3\\Databases\\BC_Data.db')
        c = con.cursor()

        c.execute("SELECT * FROM Results WHERE Name=?", (searchedname,))
        r = c.fetchall()

        print(sorted(r))

        con.close()


    #----------------# UNKNOWN CLASS PROCEDURE #----------------#

    else:
        
        print("#                                                          #")        
        print("#----------------------------------------------------------#")
        print("#                                                          #")
        print("#            Unknown class, restart program.               #")
        print("#                                                          #")
        print("#----------------------------------------------------------#")
        
